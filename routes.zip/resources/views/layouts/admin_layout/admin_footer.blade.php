<footer class="main-footer">
    <strong>Copyright &copy; 2023-2025.</strong>
    All rights reserved.
</footer>
