<div class="col-lg-3 col-md-4">
    <div class="page-menu-wrap">
        <ul class="menu-items">
            <li class="menu-item"><a class="menu-link" href="{{ route('return_policy') }}"><i
                        class="menu-icon far fa-file-alt"></i>{{ __('Return Policy') }}</a></li>
            <li class="menu-item"><a class="menu-link" href="{{ route('faq') }}"><i
                        class="menu-icon far fa-file-alt"></i>{{ __('FAQ') }}</a></li>
            <li class="menu-item"><a class="menu-link" href="{{ route('privacy_policy') }}"><i
                        class="menu-icon far fa-file-alt"></i>{{ __('Privacy Policy') }}</a></li>
            <li class="menu-item"><a class="menu-link" href="{{ route('terms_condition') }}"><i
                        class="menu-icon far fa-file-alt"></i>{{ __('Terms and Conditions') }}</a></li>
        </ul>
    </div>
</div>
