<?php
use Illuminate\Support\Facades\Session;
?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Catalogues</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Products</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <?php if(session::has('Success_message')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert" style="margin-top: 10px;">
                <?php echo e(Session::get('Success_message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
          <?php endif; ?>
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Products</h3>
                <a class="btn btn-success float-right text-white" href="<?php echo e(url('admin/add-edit-product')); ?>">Add Product</a>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="products" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>ID</th>
                    <th>PRODUCT NAME</th>
                    <th>PRODUCT CODE</th>
                    <th>PRODUCT COLOR</th>
                    <th>PRODUCT IMAGE</th>
                    <th>CATEGORY</th>
                    <th>SECTION</th>
                    <th>STATUS</th>
                    <th>ACTION</th>

                  </tr>
                  </thead>
                  <tbody>
                  <tr>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <td><?php echo e($product->id); ?></td>
                    <td><?php echo e($product->product_name); ?></td>
                    <td><?php echo e($product->product_code); ?></td>
                    <td><?php echo e($product->product_color); ?></td>
                    <td>
                        <?php $product_image_path = 'images/product_images/small/'.$product->main_image; ?>
                        <?php if(!empty($product->main_image) && file_exists($product_image_path)): ?>
                            <img src="<?php echo e(asset('images/product_images/small/'.$product->main_image)); ?>" width="100px" height="100px">
                            <?php else: ?>
                            <img src="<?php echo e(asset('images/product_images/small/no_image.png')); ?>" width="100px" height="100px">
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($product->category->category_name); ?></td>
                    <td><?php echo e($product->section->name); ?></td>
                    <td>
                    <?php if($product->status ==1): ?>
                        <a class="updateProductStatus" id="product-<?php echo e($product->id); ?>" product_id="<?php echo e($product->id); ?>" href="javascript:void(0)">Active</a>
                    <?php else: ?>
                    <a class="updateProductStatus" id="product-<?php echo e($product->id); ?>" $product_id="<?php echo e($product->id); ?>" href="javascript:void(0)">Inactive</a>
                    <?php endif; ?>
                    </td>
                    <td>
                        <a title="Add/Edit attribute" href=" <?php echo e(urL('admin/add-attributes/'.$product->id)); ?> "><i class="fa fa-plus"></i></a>
                        <a title="Add images" href=" <?php echo e(urL('admin/add-images/'.$product->id)); ?> "><i class="fa fa-plus-circle"></i></a>
                        <a title="Edit product" href=" <?php echo e(urL('admin/add-edit-product/'.$product->id)); ?> "><i class="fa fa-edit"></i></a>
                        <a title="Delete product"  href='javascript:void(0)' class="confirmDelete" record="product" recordid="<?php echo e($product->id); ?>"
                        <?php /*  href=" {{ urL('admin/delete-category/'.$product->id)}} " */ ?>><i class="fa fa-trash"></i></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </tbody>

                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\REO\Desktop\ecommerce\resources\views/admin/products/products.blade.php ENDPATH**/ ?>