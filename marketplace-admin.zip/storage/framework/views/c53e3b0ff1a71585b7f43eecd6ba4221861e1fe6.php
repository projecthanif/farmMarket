<div class="form-group">
    <label>Select Category Level</label>
    <select name="parent_id" id="parent_id" class="form-control select2" style="width: 100%;">
    <option value="0" <?php if(isset($categoryData['parent_id'])&& $categoryData['parent_id']==0): ?>  selected  <?php endif; ?>>Main Category</option>
        <?php if(!empty($getCategories)): ?>
            <?php $__currentLoopData = $getCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category['id']); ?>"  <?php if(isset($categoryData['parent_id'])&& $categoryData['parent_id']==$category['id']): ?>  selected  <?php endif; ?>>
                     <?php echo e($category['category_name']); ?> </option>

            <?php if(!empty($category['subCategories'])): ?>
                <?php $__currentLoopData = $category['subCategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($subcategory['id']); ?>">&nbsp;&raquo;&nbsp; <?php echo e($subcategory['category_name']); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
</select>
</div>
<?php /**PATH C:\Users\REO\Desktop\ecommerce\resources\views/admin/categories/append_categories_level.blade.php ENDPATH**/ ?>