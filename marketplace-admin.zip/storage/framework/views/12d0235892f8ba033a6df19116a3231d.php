<?php
use Illuminate\Support\Facades\Session; ?>

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">

        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Catalogues</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active">Products</li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>

        <section class="content">
            <form name="productform" id="productForm"
                <?php if(empty($productData['id'])): ?> action="<?php echo e(url('admin/add-edit-product')); ?>"
      <?php else: ?> action="<?php echo e(url('admin/add-edit-product/' . $productData['id'])); ?>" <?php endif; ?>
                method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                <div class="container-fluid">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert" style="margin-top: 10px">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <button type="button" class="close" data-dismiss="alert" aria-label="close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <?php if(session::has('flash_message_success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert"
                            style="margin-top: 10px;">
                            <?php echo e(Session::get('flash_message_success')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div class="card card-default">
                        <div class="card-header">
                            <h3 class="card-title"><?php echo e($title); ?></h3>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i
                                        class="fas fa-minus"></i></button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove"><i
                                        class="fas fa-times"></i></button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Select Category</label>
                                        <select name="category_id" id="category_id" class="form-control select2"
                                            style="width: 100%;">
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category['id']); ?>"
                                                    <?php if(!empty($productData['category_id']) && $productData['category_id'] == $category['id']): ?> selected <?php endif; ?>>
                                                    <?php echo e($category['name']); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="product_name">Product Name</label>
                                        <input type="text" class="form-control" id="product_name" name="product_name"
                                            placeholder="Enter product Name"
                                            <?php if(!empty($productData['product_name'])): ?> value=" <?php echo e($productData['product_name']); ?>" <?php else: ?> value="<?php echo e(old('product_name')); ?>" <?php endif; ?>>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="price">Product Price</label>
                                        <input type="text" class="form-control" id="price" name="price"
                                            placeholder="Enter product Price"
                                            <?php if(!empty($productData['price'])): ?> value=" <?php echo e($productData['price']); ?>" <?php else: ?> value="<?php echo e(old('price')); ?>" <?php endif; ?>>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="product_weight">Product Weight</label>
                                        <input type="text" class="form-control" id="product_weight" name="product_weight"
                                            placeholder="Enter product Weight"
                                            <?php if(!empty($productData['product_weight'])): ?> value=" <?php echo e($productData['product_weight']); ?>" <?php else: ?> value="<?php echo e(old('product_weight')); ?>" <?php endif; ?>>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="product_discount">Product Discount (%)</label>
                                        <input type="text" class="form-control" id="product_discount"
                                            name="product_discount" placeholder="Enter product Discount"
                                            <?php if(!empty($productData['product_discount'])): ?> value=" <?php echo e($productData['product_discount']); ?>" <?php else: ?> value="<?php echo e(old('product_discount')); ?>" <?php endif; ?>>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="main_image">Product Main Image</label>
                                        <div class="input-group">
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="main_image"
                                                    name="main_image">
                                                <label class="custom-file-label" for="main_image">Choose file</label>
                                            </div>
                                            <div class="input-group-append">
                                                <span class="input-group-text" id="">Upload</span>
                                            </div>
                                        </div>
                                        <div style="color: grey;">Recommended Image size: Width:1040px Height:1180px
                                        </div>
                                        <?php if(!empty($productData['main_image'])): ?>
                                            <img src=" <?php echo e(asset('images/product_images/small/' . $productData['main_image'])); ?> "style="margin-top:1%;"
                                                height="100px" width="100px">
                                            &nbsp;<a class="confirmDelete" record="product-image"
                                                recordid="<?php echo e($productData['id']); ?>" href="javascript:void(0)">Delete
                                                Image</a>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="product_description">Product Description</label>
                                        <textarea class="form-control" id="description" name="description" rows="3" placeholder="Enter ...">
<?php if(!empty($productData['description'])): ?>
<?php echo e($productData['description']); ?>

<?php endif; ?>
</textarea>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="quantity">Product Quantity</label>
                                        <input type="text" class="form-control" id="quantity" name="quantity"
                                            placeholder="Enter product Quantity"
                                            <?php if(!empty($productData['quantity'])): ?> value=" <?php echo e($productData['quantity']); ?>" <?php else: ?> value="<?php echo e(old('quantity')); ?>" <?php endif; ?>>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="meta_keywords">Featured Item</label>
                                    <?php $is_featured = 'Yes'; ?>
                                    <input type="checkbox" name="is_featured" id="is_featured" value="Yes"
                                        <?php if(!empty($productData['is_featured']) && $productData['is_featured'] == $is_featured): ?> checked <?php endif; ?>>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>

    </div>
    </form>
    </section>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\REO\Desktop\Marketplace-admin\resources\views/admin/products/add_edit_product.blade.php ENDPATH**/ ?>