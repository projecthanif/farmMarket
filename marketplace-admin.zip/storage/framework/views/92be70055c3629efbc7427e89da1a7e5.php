<footer class="main-footer">
    <strong>Copyright &copy; 2023-2025.</strong>
    All rights reserved.
</footer>
<?php /**PATH C:\Users\REO\Desktop\Marketplace-admin\resources\views/layouts/admin_layout/admin_footer.blade.php ENDPATH**/ ?>