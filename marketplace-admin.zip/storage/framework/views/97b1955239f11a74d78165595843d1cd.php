<?php
use Illuminate\Support\Facades\Session;
?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Catalogues</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active">Orders</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <?php if(session::has('Success_message')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert"
                                style="margin-top: 10px;">
                                <?php echo e(Session::get('Success_message')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Orders</h3>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="categories" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>ORDER ID</th>
                                            <th>IMAGE</th>
                                            <th>USER DETAILS</th>
                                            <th>ADDRESS</th>
                                            <th>PRODUCT</th>
                                            <th>PAYMENT</th>
                                            <th>TOTAL</th>
                                            <th>STATUS</th>
                                            <th>ACTION</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td><?php echo e($index + 1); ?></td>
                                                <td>#<?php echo e($order->order_id); ?></td>
                                                <td>
                                                    <?php $order_image_path = 'images/product_images/small/' . $order->product->main_image; ?>
                                                    <?php if(!empty($order->product->main_image)): ?>
                                                        <img src="<?php echo e(asset('images/product_images/small/' . $order->product->main_image)); ?>"
                                                            width="60px" height="60px">
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('images/product_images/small/no_image.png')); ?>"
                                                            width="60px" height="60px">
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <p>
                                                        <?php echo e($order->addresses->fullname ?? 'None'); ?>

                                                    </p>
                                                    <p>
                                                        <?php echo e($order->addresses->phone ?? 'None'); ?>

                                                    </p>
                                                </td>
                                                <td><?php echo e(($order->addresses->address ?? 'None') . ', ' . ($order->addresses->city ?? 'None') . ', ' . ($order->addresses->state ?? 'None')); ?>

                                                </td>
                                                <td><?php echo e($order->product->product_name); ?></td>
                                                <td>
                                                    <?php if($order->payment_status == 'paid'): ?>
                                                        <a class="updateOrderStatus" id="order-<?php echo e($order->id); ?>"
                                                            order_id="<?php echo e($order->id); ?>" href="javascript:void(0)">
                                                            paid</a>
                                                    <?php else: ?>
                                                        <a class="updateOrderStatus" id="order-<?php echo e($order->id); ?>"
                                                            order_id="<?php echo e($order->id); ?>" href="javascript:void(0)">
                                                            unpaid</a>
                                                    <?php endif; ?>
                                                </td>
                                                <td>₦<?php echo e($order->qty * $order->product->price); ?> (<?php echo e($order->qty); ?>

                                                    Item<?php echo e($order->qty > 1 ? 's' : ''); ?>)
                                                </td>
                                                <td><?php echo e($order->order_status); ?></td>
                                                <td>
                                                    <form method="post"
                                                        action="<?php echo e(url('/admin/update-order-status/' . $order->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <select class="form-control" name="order_status">
                                                            <option value="1"
                                                                <?php if($order->track_order == '1'): ?> selected <?php endif; ?>>Order
                                                                confirmed</option>
                                                            <option value="2"
                                                                <?php if($order->track_order == '2'): ?> selected <?php endif; ?>>Driver
                                                                assigned</option>
                                                            <option value="3"
                                                                <?php if($order->track_order == '3'): ?> selected <?php endif; ?>>In transit
                                                            </option>
                                                            <option value="4"
                                                                <?php if($order->track_order == '4'): ?> selected <?php endif; ?>>Completed
                                                            </option>
                                                        </select>
                                                        <button type="submit"
                                                            class="btn btn-primary w-100 mt-2">Update</button>
                                                    </form>
                                                </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>

                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\REO\Desktop\Farmers-marketplace\marketplace-admin\resources\views/admin/orders.blade.php ENDPATH**/ ?>