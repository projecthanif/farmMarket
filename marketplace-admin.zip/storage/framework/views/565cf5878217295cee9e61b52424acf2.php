<?php
    use Illuminate\Support\Facades\Session;
?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">


    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Update Details</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Admin Settings</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
          <div class="row">
            <!-- left column -->
            <div class="col-md-6">
              <!-- general form elements -->
              <div class="card card-primary">
                <div class="card-header">
                  <h3 class="card-title">Update Admin Details</h3>
                </div>

                <?php if(session::has('error_message')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert" style="margin-top: 10px;">
                    <?php echo e(Session::get('error_message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
              <?php endif; ?>
                <?php if(session::has('Success_message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert" style="margin-top: 10px;">
                    <?php echo e(Session::get('Success_message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
              <?php endif; ?>

                 
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger" style="margin-top: 10px">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                <!-- /.card-header -->
                <!-- form start -->
                <form role="form" method="POST" action="<?php echo e(url('/admin/update-admin-details')); ?>" id="updateAdminDetails" name="updateAdminDetails"
                 enctype="multipart/form-data"><?php echo csrf_field(); ?>
                    <div class="card-body">

                      <div class="form-group">
                        <label for="exampleInputEmail1">Admin Email</label>
                        <input class="form-control" readonly value="<?php echo e(Auth::guard('admin')->user()->email); ?>">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputEmail1">Admin Type</label>
                        <input class="form-control" readonly value="<?php echo e(Auth::guard('admin')->user()->type); ?>">
                      </div>

                    <div class="form-group">
                      <label for="current_pwd">Admin Name</label>
                      <input type="text" class="form-control" id="admin_name" name="admin_name" value="<?php echo e(Auth::guard('admin')->user()->name); ?>" placeholder="Enter Admin Name" required>
                      <span id="chkCurrentPass"></span>
                    </div>

                    <div class="form-group">
                      <label for="new_pwd">Admin Mobile</label>
                      <input type="text" class="form-control" id="admin_mobile" value="<?php echo e(Auth::guard('admin')->user()->mobile); ?>" name="admin_mobile" placeholder="Enter Admin mobile" required>
                    </div>

                    <div class="form-group">
                      <label for="confirm_pwd">Image</label>
                      <input type="file" class="form-control" id="admin_image" name="admin_image" accept="image/*">
                      <?php if(!empty(Auth::guard('admin')->user()->image)): ?>
                        <a target="_blank" href="<?php echo e(url('images/admin_images/admin_photos/'.Auth::guard('admin')->user()->image)); ?>">View Image</a>
                        <input type="hidden" name="current_admin_image" value="<?php echo e(Auth::guard('admin')->user()->image); ?>">
                      <?php endif; ?>
                    </div>



                  </div>
                  <!-- /.card-body -->

                  <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
              </div>
              <!-- /.card -->

              <!-- Form Element sizes -->

            <!--/.col (right) -->
          </div>
          <!-- /.row -->
        </div><!-- /.container-fluid -->
      </section>
    <!-- /.content -->
  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\REO\Desktop\Marketplace-admin\resources\views/admin/update_admin_details.blade.php ENDPATH**/ ?>