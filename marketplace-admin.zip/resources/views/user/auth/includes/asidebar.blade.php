<div class="col-xl-3 col-lg-4">
    <div class="section-wrap account-page-sidemenu user-profile-sidebar">
        <nav class="account-page-menu">
            <ul>
                <li class="active"><a href="{{ route('user.profile') }}"><i
                            class="fas fa-user"></i>My Profile</a></li>
                <li class><a href="{{ route('user.order') }}"><i
                            class="fas fa-box-open"></i>My Order</a></li>
                            <li class><a href="{{ route('user.review') }}"><i
                                class="fas fa-user-edit"></i>My Review</a></li>

            </ul>
        </nav>
    </div>
</div>
